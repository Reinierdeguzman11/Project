function Photos() {
    return (
      <div>
        <h1>Photos</h1>
      </div>
    );
  }
  
  export default Photos;