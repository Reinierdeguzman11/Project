function Cast() {
    return (
      <div>
        <h1>Cast</h1>
      </div>
    );
  }
  
  export default Cast;